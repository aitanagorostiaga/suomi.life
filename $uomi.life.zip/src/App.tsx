import { useState } from "react";
import { GameMap } from "./components/GameMap";
import { CharacterStats } from "./components/CharacterStats";
import { InteractionModal } from "./components/InteractionModal";
import { EventModal } from "./components/EventModal";
import { GameOver } from "./components/GameOver";
import { StartMenu } from "./components/StartMenu";
import { EndGame } from "./components/EndGame";
import { ResultModal } from "./components/ResultModal";
import { MenuModal } from "./components/MenuModal";
import { PersonalInfoPage } from "./components/PersonalInfoPage";
import { CharacterDesignPage } from "./components/CharacterDesignPage";
import { QuizPage } from "./components/QuizPage";
import { GraduationPage } from "./components/GraduationPage";
import { LifeEventPopup } from "./components/LifeEventPopup";
import { motion } from "motion/react";
import {
  TrendingUp,
  TrendingDown,
  Briefcase,
} from "lucide-react";
import {
  getRandomLifeEvent,
  LifeEvent,
} from "./data/lifeEvents";

export interface GameState {
  age: number;
  cash: number;
  happiness: number;
  fun: number;
  stress: number;
  safety: number;
  social: number;
  job: string;
  salary: number;
  debt: number;
  savings: number;
  currentLocation: string | null;
  characterName?: string;
  characterAvatar?: string;
  characterGender?: string;
  quizAnswers?: Record<string, string>;
  quizScore?: number;
  storylineTitle?: string;
  locationsVisited: string[];
  monthlyBudget?: {
    needs: Record<string, number>;
    wants: Record<string, number>;
    savingsInvesting: Record<string, number>;
    notes: Record<string, string>;
    wantNames?: Record<string, string>;
  };
  budgetCompleted?: boolean;
  history: string[]; // Track decision flags like 'hasBudget', 'ignoredBudgeting', 'wentIntoDebt', etc.
}

export interface Location {
  id: string;
  name: string;
  icon: string;
}

type GameScreen =
  | "start"
  | "personalInfo"
  | "characterDesign"
  | "quiz"
  | "graduation"
  | "playing"
  | "gameOver"
  | "end";

function App() {
  const [currentScreen, setCurrentScreen] =
    useState<GameScreen>("start");
  const [gameState, setGameState] = useState<GameState>({
    age: 18,
    cash: 500,
    happiness: 75,
    fun: 50,
    stress: 30,
    safety: 70,
    social: 60,
    job: "Part-time Cashier",
    salary: 1200,
    debt: 0,
    savings: 0,
    currentLocation: "home",
    characterName: "Helka",
    characterAvatar: "https://i.imgur.com/EQWX1sX.png",
    characterGender: "other",
    storylineTitle: "Entrepreneur",
    locationsVisited: [],
    budgetCompleted: false,
    history: [],
  });

  // Temporary storage for account creation flow
  const [playerName, setPlayerName] = useState("");
  const [playerAge, setPlayerAge] = useState(0);

  const [selectedLocation, setSelectedLocation] =
    useState<Location | null>(null);
  const [currentEvent, setCurrentEvent] = useState<any>(null);
  const [showResult, setShowResult] = useState(false);
  const [lastChoice, setLastChoice] = useState<any>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [lifeEvent, setLifeEvent] = useState<LifeEvent | null>(
    null,
  );

  const handleLogin = () => {
    setCurrentScreen("playing");
  };

  const handleCreateAccount = () => {
    setCurrentScreen("personalInfo");
  };

  const handlePersonalInfoNext = (
    name: string,
    age: number,
  ) => {
    setPlayerName(name);
    setPlayerAge(age);
    setCurrentScreen("characterDesign");
  };

  const handleCharacterDesignNext = (
    characterName: string,
    avatar: string,
    gender: string,
  ) => {
    setGameState((prev) => ({
      ...prev,
      characterName,
      characterAvatar: avatar,
      characterGender: gender,
    }));
    setCurrentScreen("quiz");
  };

  const handleQuizComplete = (
    answers: Record<string, string>,
    score: number,
    storylineTitle: string,
  ) => {
    setGameState((prev) => ({
      ...prev,
      quizAnswers: answers,
      quizScore: score,
      storylineTitle: storylineTitle,
    }));
    setCurrentScreen("graduation");
  };

  const handleGraduationComplete = () => {
    setCurrentScreen("playing");
  };

  const handleLocationClick = (location: Location) => {
    setSelectedLocation(location);
  };

  const handleCloseInteraction = () => {
    setSelectedLocation(null);
  };

  const handleChoice = (choice: any) => {
    // Check if this is coming from home location before processing
    const isHomeScenario = selectedLocation?.id === "home";

    // Update game state based on choice
    setGameState((prev) => {
      const newState = { ...prev };

      // Track decision flags for future scenarios
      if (choice.flag) {
        if (!newState.history) {
          newState.history = [];
        }
        newState.history.push(choice.flag);
      }

      // Handle both moneyChange (from scenarios) and cashChange (legacy)
      if (choice.moneyChange)
        newState.cash += choice.moneyChange;
      if (choice.cashChange) newState.cash += choice.cashChange;
      if (choice.happinessChange)
        newState.happiness = Math.min(
          100,
          Math.max(
            0,
            newState.happiness + choice.happinessChange,
          ),
        );
      if (choice.funChange)
        newState.fun = Math.min(
          100,
          Math.max(0, newState.fun + choice.funChange),
        );
      if (choice.stressChange)
        newState.stress = Math.min(
          100,
          Math.max(0, newState.stress + choice.stressChange),
        );
      if (choice.safetyChange)
        newState.safety = Math.min(
          100,
          Math.max(0, newState.safety + choice.safetyChange),
        );
      if (choice.socialChange)
        newState.social = Math.min(
          100,
          Math.max(0, newState.social + choice.socialChange),
        );
      if (choice.debtChange)
        newState.debt = Math.max(
          0,
          newState.debt + choice.debtChange,
        );
      if (choice.savingsChange)
        newState.savings = Math.max(
          0,
          newState.savings + choice.savingsChange,
        );

      // Apply automatic financial stress/wellbeing effects based on debt and cash
      const applyFinancialStressEffects = () => {
        let stressChange = 0;
        let safetyChange = 0;
        let happinessChange = 0;
        let funChange = 0;

        // HIGH DEBT effects (negative)
        if (newState.debt > 10000) {
          stressChange += 15;
          safetyChange -= 20;
          happinessChange -= 15;
        } else if (newState.debt > 5000) {
          stressChange += 10;
          safetyChange -= 15;
          happinessChange -= 10;
        } else if (newState.debt > 2000) {
          stressChange += 5;
          safetyChange -= 8;
          happinessChange -= 5;
        }

        // NEGATIVE CASH effects (additional stress)
        if (newState.cash < 0) {
          stressChange += 20;
          safetyChange -= 15;
          happinessChange -= 10;
        } else if (newState.cash < 100) {
          stressChange += 10;
          safetyChange -= 10;
          happinessChange -= 5;
        }

        // POSITIVE effects: No debt + Good cash (positive)
        if (newState.debt === 0 && newState.cash > 2000) {
          stressChange -= 15;
          safetyChange += 20;
          happinessChange += 10;
          funChange -= 5;
        } else if (newState.debt === 0 && newState.cash > 500) {
          stressChange -= 10;
          safetyChange += 15;
          happinessChange += 5;
          funChange -= 3;
        }

        // Apply changes with bounds
        newState.stress = Math.min(
          100,
          Math.max(0, newState.stress + stressChange),
        );
        newState.safety = Math.min(
          100,
          Math.max(0, newState.safety + safetyChange),
        );
        newState.happiness = Math.min(
          100,
          Math.max(0, newState.happiness + happinessChange),
        );
        newState.fun = Math.min(
          100,
          Math.max(0, newState.fun + funChange),
        );
      };

      // Apply financial stress effects
      applyFinancialStressEffects();

      // Track location visited
      if (
        selectedLocation &&
        !prev.locationsVisited.includes(selectedLocation.id)
      ) {
        newState.locationsVisited = [
          ...prev.locationsVisited,
          selectedLocation.id,
        ];
      }

      // Check if completed all 4 locations for this round
      const allLocations = [
        "home",
        "hospital",
        "school",
        "casino",
      ];
      const completedRound = allLocations.every((loc) =>
        newState.locationsVisited.includes(loc),
      );

      if (completedRound) {
        // Increment age by 1 year after completing all locations
        newState.age += 1;
        // Reset locations visited for next round
        newState.locationsVisited = [];
      }

      // Update current location when interaction is closed
      if (selectedLocation) {
        newState.currentLocation = selectedLocation.id;
      }

      // Check if game should end
      if (newState.age >= 23) {
        setTimeout(() => {
          setCurrentScreen("end");
        }, 500);
      }

      return newState;
    });

    setSelectedLocation(null);
    setLastChoice(choice);
    setShowResult(true);

    // 30% chance to trigger life event after home scenario
    if (isHomeScenario && Math.random() < 0.3) {
      // Small delay so result modal shows first
      setTimeout(() => {
        const event = getRandomLifeEvent(gameState.history);
        if (event) {
          setLifeEvent(event);
        }
      }, 500);
    }
  };

  const triggerRandomEvent = () => {
    const events = [
      {
        title: "🎉 Birthday!",
        description: "You're getting older! Time passes...",
        image: "birthday celebration",
        choices: [
          {
            text: "Celebrate responsibly ($50)",
            cashChange: -50,
            happinessChange: 15,
          },
          {
            text: "Skip the party, save money",
            happinessChange: -5,
          },
        ],
      },
      {
        title: "💼 Work Opportunity",
        description:
          "Your boss offers you extra hours this month.",
        image: "office workspace",
        choices: [
          {
            text: "Work overtime (+$300)",
            cashChange: 300,
            happinessChange: -10,
          },
          {
            text: "Maintain work-life balance",
            happinessChange: 5,
          },
        ],
      },
    ];

    const randomEvent =
      events[Math.floor(Math.random() * events.length)];
    setCurrentEvent(randomEvent);
  };

  const handleEventChoice = (choice: any) => {
    setGameState((prev) => {
      const newState = { ...prev };

      if (choice.cashChange) newState.cash += choice.cashChange;
      if (choice.happinessChange)
        newState.happiness = Math.min(
          100,
          Math.max(
            0,
            newState.happiness + choice.happinessChange,
          ),
        );

      // Check game over conditions
      if (newState.age >= 23) {
        setCurrentScreen("end");
      }

      return newState;
    });

    setCurrentEvent(null);
  };

  const handleRestart = () => {
    setGameState({
      age: 18,
      cash: 500,
      happiness: 75,
      fun: 50,
      stress: 30,
      safety: 70,
      social: 60,
      job: "Part-time Cashier",
      salary: 1200,
      debt: 0,
      savings: 0,
      currentLocation: "home",
      characterName: "Helka",
      characterAvatar: "https://i.imgur.com/EQWX1sX.png",
      characterGender: "other",
      storylineTitle: "Entrepreneur",
      locationsVisited: [],
      budgetCompleted: false,
      history: [],
    });
    setCurrentScreen("start");
    setSelectedLocation(null);
    setCurrentEvent(null);
    setShowResult(false);
    setLastChoice(null);
    setShowMenu(false);
    setLifeEvent(null);
  };

  // Show start menu
  if (currentScreen === "start") {
    return (
      <StartMenu
        onLogin={handleLogin}
        onCreateAccount={handleCreateAccount}
      />
    );
  }

  // Show personal info page
  if (currentScreen === "personalInfo") {
    return <PersonalInfoPage onNext={handlePersonalInfoNext} />;
  }

  // Show character design page
  if (currentScreen === "characterDesign") {
    return (
      <CharacterDesignPage
        playerName={playerName}
        onNext={handleCharacterDesignNext}
        onBack={() => setCurrentScreen("personalInfo")}
      />
    );
  }

  // Show quiz page
  if (currentScreen === "quiz") {
    return (
      <QuizPage
        playerName={playerName}
        onComplete={handleQuizComplete}
        onBack={() => setCurrentScreen("characterDesign")}
      />
    );
  }

  // Show graduation page
  if (currentScreen === "graduation") {
    return (
      <GraduationPage
        characterName={gameState.characterName || "Helka"}
        storylineTitle={gameState.storylineTitle}
        onComplete={handleGraduationComplete}
      />
    );
  }

  // Show game over screen
  if (currentScreen === "gameOver") {
    return (
      <GameOver
        gameState={gameState}
        onRestart={handleRestart}
      />
    );
  }

  // Show end game screen
  if (currentScreen === "end") {
    return (
      <EndGame
        gameState={gameState}
        onRestart={handleRestart}
      />
    );
  }

  // Show main game
  return (
    <div
      className="min-h-screen relative overflow-hidden"
      style={{
        backgroundImage:
          "url(https://i.imgur.com/yRjp0aR.jpeg)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Full-screen map container */}
      <div className="fixed inset-0">
        <GameMap
          onLocationClick={handleLocationClick}
          currentLocation={gameState.currentLocation}
          locationsVisited={gameState.locationsVisited}
        />
      </div>

      {/* Floating Stats Menu - positioned at bottom-left corner */}
      <div className="fixed bottom-4 left-4 z-30 max-w-md">
        <CharacterStats gameState={gameState} />
      </div>

      {/* Top Left Corner - Salary, Savings and Debt (Horizontal) */}
      <div className="fixed top-4 left-4 z-30 flex gap-3">
        {/* Salary Box */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white/95 backdrop-blur rounded-2xl px-5 py-3 shadow-2xl"
        >
          <div className="flex items-center gap-3">
            <div className="bg-indigo-500 text-white w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <p className="text-gray-600 text-sm">Salary</p>
              <p className="text-gray-800">
                {new Intl.NumberFormat("en-FI", {
                  style: "currency",
                  currency: "EUR",
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0,
                }).format(gameState.salary)}
                /mo
              </p>
            </div>
          </div>
        </motion.div>

        {/* Savings Box */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/95 backdrop-blur rounded-2xl px-5 py-3 shadow-2xl"
        >
          <div className="flex items-center gap-3">
            <div
              className="text-white w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: "#14c114" }}
            >
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <p className="text-gray-600 text-sm">Savings</p>
              <p className="text-gray-800">
                {new Intl.NumberFormat("en-FI", {
                  style: "currency",
                  currency: "EUR",
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0,
                }).format(gameState.savings)}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Debt Box */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/95 backdrop-blur rounded-2xl px-5 py-3 shadow-2xl"
        >
          <div className="flex items-center gap-3">
            <div className="bg-red-500 text-white w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0">
              <TrendingDown className="w-5 h-5" />
            </div>
            <div>
              <p className="text-gray-600 text-sm">Debt</p>
              <p className="text-gray-800">
                {new Intl.NumberFormat("en-FI", {
                  style: "currency",
                  currency: "EUR",
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0,
                }).format(gameState.debt)}
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Top Center - Storyline Title */}
      {gameState.storylineTitle && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-30">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-red-500 text-white rounded-2xl px-6 py-3 shadow-2xl border-2 border-red-300"
          >
            <p className="text-[10px] uppercase tracking-wider opacity-90 text-center">
              Your Story
            </p>
            <p className="text-center whitespace-nowrap">
              {gameState.storylineTitle}
            </p>
          </motion.div>
        </div>
      )}

      {/* Top Right Corner - Menu */}
      <div className="fixed top-4 right-4 z-30">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowMenu(true)}
          className="bg-white/95 backdrop-blur rounded-2xl px-6 py-3 shadow-2xl hover:shadow-3xl transition-all cursor-pointer"
        >
          <h1 className="text-gray-800">💰 Menu</h1>
        </motion.button>
      </div>

      {/* Menu Modal */}
      {showMenu && (
        <MenuModal
          onClose={() => setShowMenu(false)}
          onReturnToMainMenu={handleRestart}
          gameState={gameState}
          setGameState={setGameState}
        />
      )}

      {selectedLocation && (
        <InteractionModal
          location={selectedLocation}
          gameState={gameState}
          setGameState={setGameState}
          onClose={handleCloseInteraction}
          onChoice={handleChoice}
        />
      )}

      {currentEvent && (
        <EventModal
          event={currentEvent}
          onChoice={handleEventChoice}
        />
      )}

      {showResult && (
        <ResultModal
          choice={lastChoice}
          gameState={gameState}
          onClose={() => setShowResult(false)}
        />
      )}

      {lifeEvent && (
        <LifeEventPopup
          lifeEvent={lifeEvent}
          gameState={gameState}
          setGameState={setGameState}
          onClose={() => setLifeEvent(null)}
        />
      )}
    </div>
  );
}

export default App;