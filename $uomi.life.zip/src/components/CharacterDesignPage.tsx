import { useState } from 'react';
import { motion } from 'motion/react';
import { User, ArrowRight, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const backgroundImage = "https://i.imgur.com/yRjp0aR.jpeg";

interface CharacterDesignPageProps {
  playerName: string;
  onNext: (characterName: string, avatar: string, gender: string) => void;
  onBack: () => void;
}

// 3 different character image avatars
const AVATAR_OPTIONS = [
  { id: 1, url: 'https://i.imgur.com/9UUUhVj.png', label: 'Character 1' },
  { id: 2, url: 'https://i.imgur.com/j3MXJG2.png', label: 'Character 2' },
  { id: 3, url: 'https://i.imgur.com/EQWX1sX.png', label: 'Character 3' },
];

const GENDER_OPTIONS = [
  { label: 'Male', value: 'male', emoji: '♂️' },
  { label: 'Female', value: 'female', emoji: '♀️' },
  { label: 'Non-binary', value: 'non-binary', emoji: '⚧️' },
  { label: 'Other', value: 'other', emoji: '✨' },
];

export function CharacterDesignPage({ playerName, onNext, onBack }: CharacterDesignPageProps) {
  const [characterName, setCharacterName] = useState('Helka');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_OPTIONS[2].url);
  const [selectedGender, setSelectedGender] = useState('female');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (characterName.trim() && selectedAvatar && selectedGender) {
      onNext(characterName.trim(), selectedAvatar, selectedGender);
    }
  };

  const isValid = characterName.trim().length > 0;

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={backgroundImage}
          alt="Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative z-10 bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl w-full max-w-2xl p-4"
      >
        {/* Header */}
        <div className="text-center mb-3">
          <h2 className="text-gray-800 mb-1">✨ Design Your Character</h2>
          <p className="text-gray-600 text-xs">Create your avatar, {playerName}!</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Character Name & Preview Combined */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1 text-gray-700 mb-1 text-xs">
                <User className="w-3 h-3" style={{ color: '#caafef' }} />
                <span>Name</span>
              </label>
              <input
                type="text"
                value={characterName}
                onChange={(e) => setCharacterName(e.target.value)}
                placeholder="Character name"
                className="w-full px-2 py-1.5 rounded-lg border-2 border-gray-200 focus:outline-none transition-all text-gray-800 text-xs"
                style={{ borderColor: characterName ? '#14c114' : undefined }}
                maxLength={20}
              />
            </div>
            
            {/* Preview */}
            <div className="rounded-lg p-2 border-2 flex items-center gap-2" style={{ 
              backgroundColor: 'rgba(202, 175, 239, 0.1)',
              borderColor: '#caafef'
            }}>
              <ImageWithFallback
                src={selectedAvatar}
                alt="Character Preview"
                className="w-12 h-12 rounded-lg object-cover"
              />
              <div className="flex-1 min-w-0">
                <p className="text-gray-800 text-xs truncate">{characterName || 'Preview'}</p>
                <p className="text-gray-600 text-[10px] truncate">
                  {GENDER_OPTIONS.find(g => g.value === selectedGender)?.emoji} {GENDER_OPTIONS.find(g => g.value === selectedGender)?.label}
                </p>
              </div>
            </div>
          </div>

          {/* Avatar Selection */}
          <div>
            <label className="text-gray-700 mb-1 block text-xs">
              Choose Your Character
            </label>
            <div className="grid grid-cols-3 gap-3">
              {AVATAR_OPTIONS.map((avatar) => (
                <motion.button
                  key={avatar.id}
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedAvatar(avatar.url)}
                  className={`rounded-lg overflow-hidden transition-all ${
                    selectedAvatar === avatar.url
                      ? 'ring-4 shadow-lg'
                      : 'ring-2 ring-gray-200'
                  }`}
                  style={selectedAvatar === avatar.url ? { 
                    ringColor: '#14c114'
                  } : {}}
                >
                  <ImageWithFallback
                    src={avatar.url}
                    alt={avatar.label}
                    className="w-full h-32 object-cover"
                  />
                </motion.button>
              ))}
            </div>
          </div>

          {/* Gender Selection */}
          <div>
            <label className="text-gray-700 mb-1 block text-xs">
              Gender
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {GENDER_OPTIONS.map((gender) => (
                <motion.button
                  key={gender.value}
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedGender(gender.value)}
                  className={`py-1.5 px-2 rounded-lg transition-all ${
                    selectedGender === gender.value
                      ? 'text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  style={selectedGender === gender.value ? {
                    backgroundColor: '#1b2cff'
                  } : {}}
                >
                  <div className="text-lg">{gender.emoji}</div>
                  <div className="text-[10px]">{gender.label}</div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex gap-2 pt-2">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={onBack}
              className="px-3 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 text-gray-700 transition-all flex items-center gap-1 text-xs"
            >
              <ArrowLeft className="w-3 h-3" />
              <span>Back</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={!isValid}
              className={`flex-1 py-2 rounded-lg shadow-lg transition-all flex items-center justify-center gap-1 text-xs ${
                isValid
                  ? 'text-white'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
              style={isValid ? { backgroundColor: '#14c114' } : {}}
            >
              <span>Next Step</span>
              <ArrowRight className="w-3 h-3" />
            </motion.button>
          </div>
        </form>

        {/* Progress Indicator */}
        <div className="mt-3 flex items-center justify-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: '#14c114' }}></div>
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: '#14c114' }}></div>
          <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
        </div>
        <p className="text-center text-gray-500 text-[10px] mt-1">Step 2 of 4</p>
      </motion.div>
    </div>
  );
}