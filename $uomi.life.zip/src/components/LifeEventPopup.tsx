import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, Wallet, AlertCircle } from 'lucide-react';
import { LifeEvent } from '../data/lifeEvents';
import { GameState } from '../App';
import { useState } from 'react';
import { MonthlyBudget } from './MonthlyBudget';

interface LifeEventPopupProps {
  lifeEvent: LifeEvent;
  gameState: GameState;
  setGameState: (state: GameState | ((prev: GameState) => GameState)) => void;
  onClose: () => void;
}

export function LifeEventPopup({ lifeEvent, gameState, setGameState, onClose }: LifeEventPopupProps) {
  const [showBudget, setShowBudget] = useState(false);
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-FI', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Apply life event changes when component mounts
  useState(() => {
    setGameState(prev => {
      const newState = { ...prev };
      
      // Apply cash change
      newState.cash += lifeEvent.cashChange;
      
      // If cash goes negative, convert to debt
      if (newState.cash < 0) {
        newState.debt += Math.abs(newState.cash);
        newState.cash = 0;
      }
      
      // Apply stat changes
      if (lifeEvent.happinessChange) {
        newState.happiness = Math.min(100, Math.max(0, newState.happiness + lifeEvent.happinessChange));
      }
      if (lifeEvent.stressChange) {
        newState.stress = Math.min(100, Math.max(0, newState.stress + lifeEvent.stressChange));
      }
      if (lifeEvent.safetyChange) {
        newState.safety = Math.min(100, Math.max(0, newState.safety + lifeEvent.safetyChange));
      }
      if (lifeEvent.funChange) {
        newState.fun = Math.min(100, Math.max(0, newState.fun + lifeEvent.funChange));
      }
      if (lifeEvent.socialChange) {
        newState.social = Math.min(100, Math.max(0, newState.social + lifeEvent.socialChange));
      }
      
      return newState;
    });
  });

  const handleUpdateBudget = () => {
    setShowBudget(true);
  };

  const handleContinue = () => {
    onClose();
  };

  const handleBudgetClose = () => {
    setShowBudget(false);
    onClose();
  };

  const isPositive = lifeEvent.cashChange > 0;

  // Show budget modal if requested
  if (showBudget) {
    return (
      <MonthlyBudget
        gameState={gameState}
        setGameState={setGameState}
        onClose={handleBudgetClose}
        onComplete={handleBudgetClose}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
      >
        {/* Header */}
        <div 
          className={`p-6 text-white relative ${isPositive ? 'bg-gradient-to-r from-green-500 to-emerald-600' : 'bg-gradient-to-r from-red-500 to-orange-600'}`}
        >
          <div className="flex items-center justify-center gap-3">
            {isPositive ? (
              <TrendingUp className="w-8 h-8" />
            ) : (
              <TrendingDown className="w-8 h-8" />
            )}
            <h2 className="text-center text-2xl">Unexpected Event!</h2>
          </div>
        </div>

        {/* Event Content */}
        <div className="p-8 space-y-6">
          {/* Event Title & Description */}
          <div className="text-center space-y-3">
            <h3 className="text-xl text-gray-800">{lifeEvent.title}</h3>
            <p className="text-gray-600 leading-relaxed">{lifeEvent.description}</p>
          </div>

          {/* Cash Change Display */}
          <div className={`p-6 rounded-2xl ${isPositive ? 'bg-green-50 border-2 border-green-300' : 'bg-red-50 border-2 border-red-300'}`}>
            <div className="flex items-center justify-center gap-2 mb-3">
              <Wallet className={`w-6 h-6 ${isPositive ? 'text-green-700' : 'text-red-700'}`} />
              <span className={`text-2xl ${isPositive ? 'text-green-700' : 'text-red-700'}`}>
                {isPositive ? '+' : ''}{formatCurrency(lifeEvent.cashChange)}
              </span>
            </div>
            
            {/* Updated Financial Status */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Cash on Hand:</span>
                <span className="text-gray-800">{formatCurrency(gameState.cash)}</span>
              </div>
              {gameState.debt > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Debt:</span>
                  <span className="text-red-600">{formatCurrency(gameState.debt)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Stat Changes (if any) */}
          {(lifeEvent.happinessChange || lifeEvent.stressChange || lifeEvent.safetyChange || lifeEvent.funChange || lifeEvent.socialChange) && (
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-600 mb-3 text-center">This also affected your stats:</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {lifeEvent.happinessChange && (
                  <div className="flex justify-between">
                    <span>😊 Happiness:</span>
                    <span className={lifeEvent.happinessChange > 0 ? 'text-green-600' : 'text-red-600'}>
                      {lifeEvent.happinessChange > 0 ? '+' : ''}{lifeEvent.happinessChange}
                    </span>
                  </div>
                )}
                {lifeEvent.stressChange && (
                  <div className="flex justify-between">
                    <span>😰 Stress:</span>
                    <span className={lifeEvent.stressChange > 0 ? 'text-red-600' : 'text-green-600'}>
                      {lifeEvent.stressChange > 0 ? '+' : ''}{lifeEvent.stressChange}
                    </span>
                  </div>
                )}
                {lifeEvent.safetyChange && (
                  <div className="flex justify-between">
                    <span>🛡️ Safety:</span>
                    <span className={lifeEvent.safetyChange > 0 ? 'text-green-600' : 'text-red-600'}>
                      {lifeEvent.safetyChange > 0 ? '+' : ''}{lifeEvent.safetyChange}
                    </span>
                  </div>
                )}
                {lifeEvent.funChange && (
                  <div className="flex justify-between">
                    <span>🎉 Fun:</span>
                    <span className={lifeEvent.funChange > 0 ? 'text-green-600' : 'text-red-600'}>
                      {lifeEvent.funChange > 0 ? '+' : ''}{lifeEvent.funChange}
                    </span>
                  </div>
                )}
                {lifeEvent.socialChange && (
                  <div className="flex justify-between">
                    <span>👥 Social:</span>
                    <span className={lifeEvent.socialChange > 0 ? 'text-green-600' : 'text-red-600'}>
                      {lifeEvent.socialChange > 0 ? '+' : ''}{lifeEvent.socialChange}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Budget Update Question */}
          <div className="bg-blue-50 border-2 border-blue-300 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-blue-900 text-sm">
                <strong>Do you want to update your monthly budget?</strong>
              </p>
              <p className="text-blue-700 text-xs mt-1">
                Adjust your budget to reflect this change in your finances.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleContinue}
              className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-4 rounded-xl transition-all"
            >
              No, Continue
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleUpdateBudget}
              className="flex-1 text-white py-4 rounded-xl shadow-lg transition-all"
              style={{ backgroundColor: '#14c114' }}
            >
              Yes, Update Budget
            </motion.button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}