import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Check, AlertCircle } from 'lucide-react';
import { GameState } from '../App';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

interface MonthlyBudgetProps {
  gameState: GameState;
  setGameState: (state: GameState | ((prev: GameState) => GameState)) => void;
  onClose: () => void;
  onComplete?: () => void;
}

export function MonthlyBudget({ gameState, setGameState, onClose, onComplete }: MonthlyBudgetProps) {
  const [showFeedback, setShowFeedback] = useState(false);
  
  // Initialize budget from gameState or defaults
  const [needs, setNeeds] = useState<Record<string, number>>(
    gameState.monthlyBudget?.needs || {
      rent: 0,
      utilities: 0,
      internet: 0,
      phonePlan: 0,
      groceries: 0,
      publicTransport: 0,
      healthcareMedication: 0,
      homeInsurance: 0,
    }
  );

  const [wants, setWants] = useState<Record<string, number>>(
    gameState.monthlyBudget?.wants || {
      want1: 0,
      want2: 0,
      want3: 0,
      want4: 0,
      want5: 0,
    }
  );

  const [wantNames, setWantNames] = useState<Record<string, string>>(
    gameState.monthlyBudget?.wantNames || {
      want1: '',
      want2: '',
      want3: '',
      want4: '',
      want5: '',
    }
  );

  const [savingsInvesting, setSavingsInvesting] = useState<Record<string, number>>(
    gameState.monthlyBudget?.savingsInvesting || {
      savings: 0,
      investing: 0,
    }
  );

  const [notes, setNotes] = useState<Record<string, string>>(
    gameState.monthlyBudget?.notes || {}
  );

  // Calculate totals
  const totalNeeds = Object.values(needs).reduce((sum, val) => sum + (Number(val) || 0), 0);
  const totalWants = Object.values(wants).reduce((sum, val) => sum + (Number(val) || 0), 0);
  const totalSavingsInvesting = Object.values(savingsInvesting).reduce((sum, val) => sum + (Number(val) || 0), 0);
  const totalBudgeted = totalNeeds + totalWants + totalSavingsInvesting;

  const monthlyIncome = gameState.salary;
  const overBudget = totalBudgeted - monthlyIncome;

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-FI', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const handleUpdateValue = (category: 'needs' | 'wants' | 'savingsInvesting', key: string, value: string) => {
    const numValue = Math.max(0, Number(value) || 0);
    
    if (category === 'needs') {
      setNeeds(prev => ({ ...prev, [key]: numValue }));
    } else if (category === 'wants') {
      setWants(prev => ({ ...prev, [key]: numValue }));
    } else {
      setSavingsInvesting(prev => ({ ...prev, [key]: numValue }));
    }
  };

  const handleUpdateNote = (key: string, value: string) => {
    setNotes(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveBudget = () => {
    // Calculate financial impact
    let newCash = gameState.cash;
    let newDebt = gameState.debt;

    if (overBudget > 0) {
      // Over budget - deduct from cash first, then add to debt
      if (newCash >= overBudget) {
        newCash -= overBudget;
      } else {
        const remaining = overBudget - newCash;
        newCash = 0;
        newDebt += remaining;
      }
    }

    // Save budget to game state
    setGameState(prev => ({
      ...prev,
      cash: newCash,
      debt: newDebt,
      monthlyBudget: {
        needs,
        wants,
        savingsInvesting,
        notes,
        wantNames,
      },
      budgetCompleted: true,
    }));

    // Show feedback
    setShowFeedback(true);
  };

  const calculate50_30_20 = () => {
    const ideal50 = monthlyIncome * 0.5;
    const ideal30 = monthlyIncome * 0.3;
    const ideal20 = monthlyIncome * 0.2;

    const needsPercentage = (totalNeeds / monthlyIncome) * 100;
    const wantsPercentage = (totalWants / monthlyIncome) * 100;
    const savingsPercentage = (totalSavingsInvesting / monthlyIncome) * 100;

    const needsDiff = Math.abs(50 - needsPercentage);
    const wantsDiff = Math.abs(30 - wantsPercentage);
    const savingsDiff = Math.abs(20 - savingsPercentage);

    const averageDiff = (needsDiff + wantsDiff + savingsDiff) / 3;

    let feedback = '';
    let statChanges = { happiness: 0, stress: 0, safety: 0 };

    if (averageDiff < 5) {
      feedback = '🎉 Excellent! Your budget follows the 50/30/20 rule almost perfectly!';
      statChanges = { happiness: 10, stress: -15, safety: 15 };
    } else if (averageDiff < 10) {
      feedback = '👍 Good job! Your budget is close to the 50/30/20 rule.';
      statChanges = { happiness: 5, stress: -10, safety: 10 };
    } else if (averageDiff < 20) {
      feedback = '⚠️ Not bad, but there\'s room for improvement. Try to balance your budget better.';
      statChanges = { happiness: 0, stress: -5, safety: 5 };
    } else {
      feedback = '❌ Your budget is far from the 50/30/20 rule. Consider adjusting your spending.';
      statChanges = { happiness: -5, stress: 5, safety: -5 };
    }

    return { feedback, statChanges, needsPercentage, wantsPercentage, savingsPercentage, ideal50, ideal30, ideal20 };
  };

  const handleCloseFeedback = () => {
    const analysis = calculate50_30_20();
    
    // Apply stat changes
    setGameState(prev => ({
      ...prev,
      happiness: Math.min(100, Math.max(0, prev.happiness + analysis.statChanges.happiness)),
      stress: Math.min(100, Math.max(0, prev.stress + analysis.statChanges.stress)),
      safety: Math.min(100, Math.max(0, prev.safety + analysis.statChanges.safety)),
    }));

    if (onComplete) {
      onComplete();
    } else {
      onClose();
    }
  };

  if (showFeedback) {
    const analysis = calculate50_30_20();

    // Prepare data for pie charts
    const yourBudgetData = [
      { name: 'Needs', value: totalNeeds, percentage: analysis.needsPercentage, color: '#1b2cff' },
      { name: 'Wants', value: totalWants, percentage: analysis.wantsPercentage, color: '#caafef' },
      { name: 'Savings', value: totalSavingsInvesting, percentage: analysis.savingsPercentage, color: '#14c114' },
    ].filter(item => item.value > 0); // Only show categories with values

    const idealBudgetData = [
      { name: 'Needs', value: 50, color: '#1b2cff' },
      { name: 'Wants', value: 30, color: '#caafef' },
      { name: 'Savings', value: 20, color: '#14c114' },
    ];

    // Custom label for pie chart
    const renderCustomLabel = (entry: any) => {
      return `${entry.name}: ${entry.value.toFixed(0)}%`;
    };

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-6 text-white relative" style={{ backgroundColor: '#14c114' }}>
            <h2 className="text-center text-2xl">📊 Budget Analysis</h2>
          </div>

          {/* Feedback Content */}
          <div className="p-8 space-y-6">
            <div className="text-center">
              <p className="text-gray-800 text-lg">{analysis.feedback}</p>
            </div>

            {/* Pie Charts Comparison */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Your Budget Pie Chart */}
              <div className="bg-gray-50 rounded-xl p-4">
                <h3 className="text-center text-gray-800 mb-2">Your Budget</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={yourBudgetData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={renderCustomLabel}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="percentage"
                    >
                      {yourBudgetData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: any, name: string) => [`${value.toFixed(1)}%`, name]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="text-center text-sm text-gray-600 mt-2">
                  Total: {formatCurrency(totalBudgeted)}
                </div>
              </div>

              {/* Ideal 50/30/20 Pie Chart */}
              <div className="bg-gray-50 rounded-xl p-4">
                <h3 className="text-center text-gray-800 mb-2">Ideal 50/30/20 Rule</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={idealBudgetData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={renderCustomLabel}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {idealBudgetData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: any, name: string) => [`${value}%`, name]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="text-center text-sm text-gray-600 mt-2">
                  Based on {formatCurrency(monthlyIncome)} income
                </div>
              </div>
            </div>

            {/* 50/30/20 Breakdown */}
            <div className="space-y-4">
              <h3 className="text-gray-800">Detailed Breakdown:</h3>
              
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Needs: {analysis.needsPercentage.toFixed(1)}%</span>
                    <span className="text-gray-600">(Target: 50%)</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="h-3 rounded-full transition-all" 
                      style={{ 
                        width: `${Math.min(analysis.needsPercentage, 100)}%`,
                        backgroundColor: '#1b2cff'
                      }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-1">{formatCurrency(totalNeeds)} / {formatCurrency(analysis.ideal50)}</p>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Wants: {analysis.wantsPercentage.toFixed(1)}%</span>
                    <span className="text-gray-600">(Target: 30%)</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="h-3 rounded-full transition-all" 
                      style={{ 
                        width: `${Math.min(analysis.wantsPercentage, 100)}%`,
                        backgroundColor: '#caafef'
                      }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-1">{formatCurrency(totalWants)} / {formatCurrency(analysis.ideal30)}</p>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Savings/Investing: {analysis.savingsPercentage.toFixed(1)}%</span>
                    <span className="text-gray-600">(Target: 20%)</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="h-3 rounded-full transition-all" 
                      style={{ 
                        width: `${Math.min(analysis.savingsPercentage, 100)}%`,
                        backgroundColor: '#14c114'
                      }}
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-1">{formatCurrency(totalSavingsInvesting)} / {formatCurrency(analysis.ideal20)}</p>
                </div>
              </div>
            </div>

            {/* Close Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleCloseFeedback}
              className="w-full text-white py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-3"
              style={{ backgroundColor: '#14c114' }}
            >
              <Check className="w-5 h-5" />
              <span>Continue</span>
            </motion.button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl my-8 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 text-white relative" style={{ backgroundColor: '#14c114' }}>
          <h2 className="text-center text-2xl">💰 Monthly Budget</h2>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Budget Info */}
        <div className="p-6 bg-gray-50 border-b border-gray-200">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div>
              <p className="text-sm text-gray-600">Monthly Income</p>
              <p className="text-2xl text-gray-800">{formatCurrency(monthlyIncome)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Cash on Hand</p>
              <p className="text-2xl text-gray-800">{formatCurrency(gameState.cash)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Budgeted</p>
              <p className={`text-2xl ${overBudget > 0 ? 'text-red-600' : 'text-green-600'}`}>
                {formatCurrency(totalBudgeted)}
              </p>
            </div>
          </div>
          
          {overBudget > 0 && (
            <div className="mt-4 p-3 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-800 text-sm">
                  <strong>Over Budget by {formatCurrency(overBudget)}</strong>
                </p>
                <p className="text-red-600 text-xs mt-1">
                  This will be deducted from your cash. If cash isn't enough, the rest becomes debt.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Budget Table */}
        <div className="p-6 overflow-x-auto" style={{ 
          maxHeight: 'calc(100vh - 400px)',
          overscrollBehavior: 'contain',
          scrollbarColor: '#14c114 #f3f4f6',
          scrollbarWidth: 'thin'
        }}>
          <table className="w-full">
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b-2 border-gray-300">
                <th className="text-left py-3 px-2 text-gray-700">Expenses</th>
                <th className="text-left py-3 px-2 text-gray-700">Budgeted (€)</th>
                <th className="text-left py-3 px-2 text-gray-700">Notes</th>
              </tr>
            </thead>
            <tbody>
              {/* Needs Section */}
              <tr className="bg-blue-50">
                <td colSpan={3} className="py-2 px-2 text-sm text-gray-800">
                  <strong>Needs</strong> (Target: 50% = {formatCurrency(monthlyIncome * 0.5)})
                </td>
              </tr>
              {Object.entries(needs).map(([key, value]) => (
                <tr key={key} className="border-b border-gray-200">
                  <td className="py-2 px-2 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</td>
                  <td className="py-2 px-2">
                    <input
                      type="number"
                      min="0"
                      value={value || ''}
                      onChange={(e) => handleUpdateValue('needs', key, e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      style={{ borderColor: '#1b2cff' }}
                    />
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="text"
                      value={notes[key] || ''}
                      onChange={(e) => handleUpdateNote(key, e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      placeholder="Add note..."
                    />
                  </td>
                </tr>
              ))}

              {/* Wants Section */}
              <tr className="bg-purple-50">
                <td colSpan={3} className="py-2 px-2 text-sm text-gray-800">
                  <strong>Wants</strong> (Target: 30% = {formatCurrency(monthlyIncome * 0.3)})
                </td>
              </tr>
              {Object.entries(wants).map(([key, value], index) => (
                <tr key={key} className="border-b border-gray-200">
                  <td className="py-2 px-2">
                    <input
                      type="text"
                      value={wantNames[key] || ''}
                      onChange={(e) => setWantNames(prev => ({ ...prev, [key]: e.target.value }))}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      placeholder={`Want ${index + 1} (e.g., Netflix, Gym, Coffee)`}
                    />
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="number"
                      min="0"
                      value={value || ''}
                      onChange={(e) => handleUpdateValue('wants', key, e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      style={{ borderColor: '#caafef' }}
                    />
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="text"
                      value={notes[key] || ''}
                      onChange={(e) => handleUpdateNote(key, e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      placeholder="Add note..."
                    />
                  </td>
                </tr>
              ))}

              {/* Savings/Investing Section */}
              <tr className="bg-green-50">
                <td colSpan={3} className="py-2 px-2 text-sm text-gray-800">
                  <strong>Savings/Investing</strong> (Target: 20% = {formatCurrency(monthlyIncome * 0.2)})
                </td>
              </tr>
              {Object.entries(savingsInvesting).map(([key, value]) => (
                <tr key={key} className="border-b border-gray-200">
                  <td className="py-2 px-2 capitalize">{key}</td>
                  <td className="py-2 px-2">
                    <input
                      type="number"
                      min="0"
                      value={value || ''}
                      onChange={(e) => handleUpdateValue('savingsInvesting', key, e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      style={{ borderColor: '#14c114' }}
                    />
                  </td>
                  <td className="py-2 px-2">
                    <input
                      type="text"
                      value={notes[key] || ''}
                      onChange={(e) => handleUpdateNote(key, e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none"
                      placeholder="Add note..."
                    />
                  </td>
                </tr>
              ))}

              {/* Total Row */}
              <tr className="bg-gray-100 border-t-2 border-gray-400">
                <td className="py-3 px-2"><strong>TOTAL</strong></td>
                <td className="py-3 px-2">
                  <strong className={overBudget > 0 ? 'text-red-600' : 'text-green-600'}>
                    {formatCurrency(totalBudgeted)}
                  </strong>
                </td>
                <td className="py-3 px-2"></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Footer Actions */}
        <div className="p-6 bg-gray-50 border-t border-gray-200 flex gap-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onClose}
            className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 rounded-xl transition-all"
          >
            Cancel
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSaveBudget}
            className="flex-1 text-white py-3 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
            style={{ backgroundColor: '#14c114' }}
          >
            <Check className="w-5 h-5" />
            <span>Complete</span>
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}