import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { LogIn, UserPlus, Award } from 'lucide-react';
import { useState } from 'react';
import { CreditsModal } from './CreditsModal';

const logoImage = "https://i.imgur.com/wj0yA7v.png";
const menuBackgroundImage = "https://i.imgur.com/yRjp0aR.jpeg";

interface StartMenuProps {
  onLogin: () => void;
  onCreateAccount: () => void;
}

export function StartMenu({ onLogin, onCreateAccount }: StartMenuProps) {
  const [showCredits, setShowCredits] = useState(false);

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={menuBackgroundImage}
          alt="Menu Background"
          className="w-full h-full object-cover"
        />
        {/* Optional overlay for better text readability */}
        <div className="absolute inset-0 bg-black/20" />
      </div>

      {/* Main menu card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl p-5 max-w-md w-full"
      >
        {/* Logo Image */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mb-3"
        >
          <div className="relative w-full rounded-2xl overflow-hidden shadow-xl mb-2">
            <ImageWithFallback
              src={logoImage}
              alt="Suomi Life"
              className="w-full h-auto object-contain py-6 px-4"
            />
          </div>
          <p className="text-center text-gray-600 text-xs">
            Learn finance through life choices
          </p>
        </motion.div>

        {/* Menu buttons */}
        <div className="space-y-2">
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onLogin}
            className="w-full text-white py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            style={{ backgroundColor: '#14c114' }}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span className="text-xs">Login</span>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onCreateAccount}
            className="w-full text-white py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            style={{ backgroundColor: '#14c114' }}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span className="text-xs">Create New Account</span>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowCredits(true)}
            className="w-full text-white py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            style={{ backgroundColor: '#1b2cff' }}
          >
            <Award className="w-3.5 h-3.5" />
            <span className="text-xs">Credits</span>
          </motion.button>
        </div>

        {/* Combined Notice */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-3 p-2 bg-blue-50 border border-blue-200 rounded-xl"
        >
          <p className="text-center text-blue-800 text-xs leading-relaxed">
            ℹ️ No data saved • Educational purposes only • All ages
          </p>
        </motion.div>

        {/* Figma Make AI Attribution */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.5 }}
          className="mt-3 pt-3 border-t border-gray-200"
        >
          <div className="text-center space-y-1">
            <p className="text-gray-600 text-xs">
              🤖 Built with <strong>Figma Make AI</strong> • MIT License
            </p>
            <p className="text-gray-500 text-[10px]">
              Junction 2025 Hackathon • Helsinki Education Hub Challenge
            </p>
          </div>
        </motion.div>

        {/* Credits Modal */}
        <CreditsModal
          isOpen={showCredits}
          onClose={() => setShowCredits(false)}
        />
      </motion.div>
    </div>
  );
}