import { useState } from 'react';
import { motion } from 'motion/react';
import { User, Calendar, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const backgroundImage = "https://i.imgur.com/yRjp0aR.jpeg";

interface PersonalInfoPageProps {
  onNext: (name: string, age: number) => void;
}

export function PersonalInfoPage({ onNext }: PersonalInfoPageProps) {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && age) {
      onNext(name.trim(), parseInt(age));
    }
  };

  const isValid = name.trim().length > 0 && age && parseInt(age) >= 0;

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={backgroundImage}
          alt="Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative z-10 bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl w-full max-w-2xl p-8"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-gray-800 text-3xl mb-2">👋 Welcome to $uomi.life</h1>
          <p className="text-gray-600">Let's get to know you first</p>
          
          {/* Important Notice */}
          <div className="mt-4 bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
            <p className="text-blue-800 text-sm">
              ℹ️ <strong>Note:</strong> No information will be saved. This is just for personalizing your game experience!
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name Input */}
          <div>
            <label className="flex items-center gap-2 text-gray-700 mb-2">
              <User className="w-5 h-5" style={{ color: '#caafef' }} />
              <span>What's your name?</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:outline-none transition-all text-gray-800"
              style={{ borderColor: name ? '#14c114' : undefined }}
              maxLength={30}
            />
          </div>

          {/* Age Input */}
          <div>
            <label className="flex items-center gap-2 text-gray-700 mb-2">
              <Calendar className="w-5 h-5" style={{ color: '#caafef' }} />
              <span>How old are you?</span>
            </label>
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder="Enter your age"
              min="0"
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:outline-none transition-all text-gray-800"
              style={{ borderColor: age ? '#14c114' : undefined }}
            />
            <p className="text-gray-500 text-sm mt-1">All ages welcome (no negative numbers)</p>
          </div>

          {/* Next Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={!isValid}
            className={`w-full py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-3 ${
              isValid
                ? 'text-white'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
            style={isValid ? { backgroundColor: '#14c114' } : {}}
          >
            <span>Next Step</span>
            <ArrowRight className="w-5 h-5" />
          </motion.button>
        </form>

        {/* Progress Indicator */}
        <div className="mt-8 flex items-center justify-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#14c114' }}></div>
          <div className="w-3 h-3 rounded-full bg-gray-300"></div>
          <div className="w-3 h-3 rounded-full bg-gray-300"></div>
          <div className="w-3 h-3 rounded-full bg-gray-300"></div>
        </div>
        <p className="text-center text-gray-500 text-sm mt-2">Step 1 of 4</p>
      </motion.div>
    </div>
  );
}