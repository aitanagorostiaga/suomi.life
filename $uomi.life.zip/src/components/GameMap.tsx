import { motion } from 'motion/react';
import { Home, Hospital, GraduationCap, Dices, MapPin } from 'lucide-react';
import { Location } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface GameMapProps {
  onLocationClick: (location: Location) => void;
  currentLocation: string | null;
  locationsVisited: string[];
}

export function GameMap({ onLocationClick, currentLocation, locationsVisited }: GameMapProps) {
  const locations = [
    { 
      id: 'home', 
      name: 'Your Home', 
      icon: 'home', 
      color: '#FDE646',
      Icon: Home,
      position: { top: '25%', left: '25%' }
    },
    { 
      id: 'school', 
      name: 'School', 
      icon: 'school', 
      color: '#B1AFF9',
      Icon: GraduationCap,
      position: { top: '25%', left: '60%' }
    },
    { 
      id: 'casino', 
      name: 'Casino', 
      icon: 'casino', 
      color: '#000000',
      Icon: Dices,
      position: { top: '50%', left: '60%' }
    },
    { 
      id: 'hospital', 
      name: 'Hospital', 
      icon: 'hospital', 
      color: '#BC1823',
      Icon: Hospital,
      position: { top: '50%', left: '25%' }
    },
  ];

  const cityBackgroundImage = "https://i.imgur.com/yRjp0aR.jpeg";

  // Find current location position for the "you" marker
  const getCurrentLocationPosition = () => {
    // If no location visited yet, start at home
    if (locationsVisited.length === 0) {
      return locations[0].position; // home
    }
    
    // Counter-clockwise order: home → school → casino → hospital → (back to home)
    const counterClockwiseOrder = ['home', 'school', 'casino', 'hospital'];
    const lastVisited = locationsVisited[locationsVisited.length - 1];
    const currentIndex = counterClockwiseOrder.indexOf(lastVisited);
    
    if (currentIndex === -1) {
      return locations[0].position;
    }
    
    // Next location in counter-clockwise order
    const nextIndex = (currentIndex + 1) % counterClockwiseOrder.length;
    const nextLocationId = counterClockwiseOrder[nextIndex];
    const nextLocation = locations.find(loc => loc.id === nextLocationId);
    
    return nextLocation?.position || locations[0].position;
  };

  const youPosition = getCurrentLocationPosition();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full h-full overflow-hidden"
    >
      {/* City Background - Full screen */}
      <div className="relative w-full h-full">
        {/* Background city image with overlay */}
        <div className="absolute inset-0">
          <ImageWithFallback
            src={cityBackgroundImage}
            alt="City Map"
            className="w-full h-full object-cover"
          />
          {/* Lighter overlay for readability */}
          <div className="absolute inset-0 bg-white/10" />
        </div>

        {/* Interactive Buildings */}
        {locations.map((location, index) => (
          <motion.div
            key={location.id}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.15, type: 'spring' }}
            className="absolute z-10"
            style={{
              top: location.position.top,
              left: location.position.left,
              transform: 'translate(-50%, -50%)'
            }}
          >
            {/* Building Button */}
            <motion.button
              whileHover={{ scale: 1.15, y: -5 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onLocationClick(location)}
              className="relative group"
            >
              {/* Building container with 3D effect */}
              <div className="relative">
                {/* Shadow */}
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-20 h-4 bg-black/30 rounded-full blur-md" />
                
                {/* Building */}
                <div 
                  className="relative rounded-2xl p-5 shadow-2xl w-24 h-24 flex flex-col items-center justify-center transition-all duration-300 group-hover:shadow-3xl border-4 border-white/50"
                  style={{ backgroundColor: location.color }}
                >
                  {/* Icon */}
                  <div className="bg-white/90 rounded-xl p-3 shadow-lg mb-1">
                    <location.Icon className="w-8 h-8 text-gray-800" />
                  </div>
                </div>

                {/* Label - shows on button hover */}
                <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                  <div className="bg-white/95 backdrop-blur rounded-xl px-4 py-2 shadow-xl border-2 border-gray-200">
                    <p className="text-gray-800">{location.name}</p>
                  </div>
                </div>
              </div>
            </motion.button>
          </motion.div>
        ))}

        {/* "You" Pin Marker */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', delay: 0.6 }}
          className="absolute z-20"
          style={{
            top: youPosition.top,
            left: youPosition.left,
            transform: 'translate(-50%, -100%)'
          }}
        >
          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="relative"
          >
            {/* Pin marker */}
            <MapPin 
              className="w-8 h-8 drop-shadow-lg" 
              style={{ 
                color: '#14c114',
                fill: '#14c114',
                stroke: '#ffffff',
                strokeWidth: 2
              }} 
            />
            {/* Label */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap">
              <div className="bg-white/95 backdrop-blur rounded-lg px-2 py-1 shadow-lg border border-gray-200">
                <p className="text-gray-800 text-xs">You</p>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Decorative elements - roads/paths connecting locations */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20" style={{ zIndex: 0 }}>
          <defs>
            <linearGradient id="roadGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#14c114" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#14c114" stopOpacity="0.5" />
            </linearGradient>
          </defs>
          {/* Connect buildings in counter-clockwise order */}
          <path d="M 25% 25% L 60% 25%" stroke="url(#roadGradient)" strokeWidth="6" fill="none" strokeDasharray="10,5" />
          <path d="M 60% 25% L 60% 50%" stroke="url(#roadGradient)" strokeWidth="6" fill="none" strokeDasharray="10,5" />
          <path d="M 60% 50% L 25% 50%" stroke="url(#roadGradient)" strokeWidth="6" fill="none" strokeDasharray="10,5" />
          <path d="M 25% 50% L 25% 25%" stroke="url(#roadGradient)" strokeWidth="6" fill="none" strokeDasharray="10,5" />
        </svg>
      </div>

      {/* Bottom instruction panel */}
      <div className="bg-white/90 backdrop-blur p-4 border-t-4" style={{ borderColor: '#14c114' }}>
        <p className="text-center text-gray-900">💡 Click on any building to make financial decisions and shape your future!</p>
      </div>
    </motion.div>
  );
}