export const scenarios: Record<string, any[]> = {
  home: [
    // AGE 18-19: Budgeting - Welcome to Your First Paycheck - Multi-page scenario
    {
      minAge: 18,
      maxAge: 19,
      title: "💰 Budgeting -- Welcome to Your First Paycheck!",
      isMultiPage: true,
      flag: "completedFirstBudget", // Track completion
      pages: [
        {
          type: "intro",
          content: {
            title:
              "💰 Budgeting -- Welcome to Your First Paycheck!",
            storyIntro:
              "You just got paid! Before you sprint to the nearest Prisma, Alko, or online shopping cart… let's learn how to make your money actually last until next payday.",
          },
        },
        {
          type: "lesson",
          content: {
            title: "The 50–30–20 Budget Rule",
            description:
              "When money comes in, divide your monthly income into:",
            sections: [
              {
                title: "50% – Needs",
                subtitle: "Things you must pay to live:",
                items: [
                  "Rent or shared-flat contribution",
                  "Groceries",
                  "Public transport card",
                  "Phone bill",
                  "Healthcare expenses",
                  "Loan payments",
                ],
              },
              {
                title: "30% – Wants",
                subtitle: "Fun money:",
                items: [
                  "Eating out",
                  "Cinema",
                  "Gaming subscriptions",
                  "Parties",
                  "Clothing",
                  "Hobbies",
                ],
              },
              {
                title: "20% – Future You",
                subtitle: "Long-term stability:",
                items: [
                  "Savings",
                  "Emergency fund (broken phone, surprise healthcare bill)",
                  "Investments (if unlocked later)",
                ],
              },
            ],
          },
        },
        {
          type: "importance",
          content: {
            title: "Why it matters",
            text: "If you don't plan your paycheck, your paycheck will plan you. Unexpected expenses come fast, especially in Finland (hello, 100€ healthcare deductible!). Budgeting = less stress + more control + more freedom.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your Task",
            description:
              'Create your first monthly budget. You\'ll be given: Your paycheck, Your fixed monthly expenses, A wishlist of "wants", A savings goal based on your storyline path.',
            choices: [
              {
                text: "A) Don't budget and spend it all in stuff.",
                happinessChange: 10,
                safetyChange: -25,
                result:
                  "You spent everything on fun stuff! It felt great... for a week. Then your phone bill came due and you had no money left. You had to skip meals and ask friends for help. The stress was overwhelming.",
                tip: "You don't have to be perfect. You just have to be aware. Your future events will respond to how well you manage your money.",
                flag: "ignoredBudgeting", // Track bad choice
              },
              {
                text: "B) Do a functional budget.",
                happinessChange: -5,
                safetyChange: 30,
                result:
                  "You created a budget using the 50-30-20 rule. It felt restrictive at first, but by the end of the month, all your bills were paid, you had fun money left, and you even started an emergency fund. You felt in control!",
                tip: "You don't have to be perfect. You just have to be aware. Your future events will respond to how well you manage your money.",
                flag: "hasBudget", // Track good choice
              },
            ],
          },
        },
      ],
      educationalNote:
        "The 50-30-20 rule helps you balance living today with preparing for tomorrow.",
    },
    
    // AGE 20-21: Rent & Bills Crisis
    {
      minAge: 20,
      maxAge: 21,
      title: "🏠 Rent Crisis: Can You Handle Adult Responsibilities?",
      isMultiPage: true,
      flag: "completedRentCrisis",
      pages: [
        {
          type: "intro",
          content: {
            title: "🏠 Rent Crisis: Can You Handle Adult Responsibilities?",
            storyIntro:
              "Your landlord just raised the rent by €150/month! Your part-time job barely covers it. Your friends are going on a weekend trip to Tallinn. What will you do?",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Managing Fixed Costs",
            description:
              "As you get older, your fixed costs increase. Rent, utilities, insurance, and subscriptions add up quickly.",
            sections: [
              {
                title: "Fixed Costs",
                subtitle: "These don't change month to month:",
                items: [
                  "Rent (largest expense for most people)",
                  "Utilities (electricity, water, internet)",
                  "Phone plan",
                  "Insurance (health, home, car)",
                  "Loan payments",
                  "Subscriptions (Netflix, Spotify, gym)",
                ],
              },
              {
                title: "Variable Costs",
                subtitle: "These change based on your choices:",
                items: [
                  "Groceries",
                  "Transportation",
                  "Entertainment",
                  "Eating out",
                  "Shopping",
                ],
              },
            ],
          },
        },
        {
          type: "importance",
          content: {
            title: "Why it matters",
            text: "When fixed costs rise, you need to either increase income or decrease variable costs. Ignoring this leads to debt. Your earlier budgeting decisions affect how prepared you are for this.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your Task",
            description:
              "Your rent increased €150/month. You need to make a choice about how to handle this crisis.",
            choices: [
              {
                text: "A) Ignore the problem and go on the trip anyway (€300).",
                cashChange: -450,
                happinessChange: 20,
                funChange: 30,
                safetyChange: -40,
                stressChange: 40,
                requiresFlag: "ignoredBudgeting", // Worse outcome if they ignored budgeting at 18
                result:
                  "You went on the trip and had an amazing time! But when you got back, the rent was due and you didn't have enough money. You had to borrow €450 from your parents. Since you never learned to budget at 18, this caught you completely off guard. Your stress levels are through the roof.",
                tip: "Living beyond your means catches up with you. Those who planned ahead are in a better position now.",
                flag: "wentIntoDebt",
              },
              {
                text: "B) Skip the trip, but don't make a plan.",
                cashChange: -150,
                happinessChange: -10,
                funChange: -20,
                stressChange: 20,
                result:
                  "You skipped the trip and covered the rent increase... barely. But without a plan, you're living paycheck to paycheck and stressed about next month.",
                tip: "You avoided immediate debt, but you need a long-term solution.",
                flag: "livingPaycheckToPaycheck",
              },
              {
                text: "C) Look for a side gig or ask for more hours.",
                cashChange: 200,
                happinessChange: -15,
                funChange: -25,
                stressChange: 15,
                safetyChange: 30,
                socialChange: -15,
                requiresFlag: "hasBudget", // Better outcome if they budgeted at 18
                result:
                  "Because you learned budgeting at 18, you knew exactly how much extra income you needed. You found a weekend gig that brings in €350/month. You're working more and have less free time, but you're covering rent and still saving a bit. You feel proud of your responsibility.",
                tip: "Your earlier good decisions are paying off! You were prepared for this challenge.",
                flag: "increasedIncome",
              },
              {
                text: "D) Negotiate with landlord and cut unnecessary expenses.",
                cashChange: -75,
                happinessChange: -5,
                stressChange: -10,
                safetyChange: 20,
                requiresFlag: "hasBudget",
                result:
                  "You negotiated with your landlord and got them to agree to only €75 increase for the first 6 months. You also reviewed your budget and cut €50 in unused subscriptions. Your budgeting skills from age 18 made this much easier to handle!",
                tip: "Communication and smart budgeting save the day!",
                flag: "negotiatedRent",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Rising fixed costs are a reality of adult life. Income growth and expense management are both important strategies.",
    },

    // AGE 22-23: Advanced Housing Decision
    {
      minAge: 22,
      maxAge: 23,
      title: "🏘️ Big Decision: Renting vs. Buying Your First Home",
      isMultiPage: true,
      flag: "completedHousingDecision",
      pages: [
        {
          type: "intro",
          content: {
            title: "🏘️ Big Decision: Renting vs. Buying",
            storyIntro:
              "You're 22-23 now. Some friends are buying their first apartments with loans. Others are renting. You need to make one of the biggest financial decisions of your life.",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Renting vs. Buying",
            description:
              "Both options have pros and cons. Your earlier financial decisions affect which option is realistic for you.",
            sections: [
              {
                title: "Renting",
                subtitle: "Pros:",
                items: [
                  "Flexibility to move",
                  "No maintenance costs",
                  "Lower upfront costs",
                  "No property taxes",
                ],
              },
              {
                title: "Buying",
                subtitle: "Pros:",
                items: [
                  "Building equity",
                  "Potential property value increase",
                  "Freedom to renovate",
                  "Long-term investment",
                ],
              },
              {
                title: "Buying",
                subtitle: "Cons:",
                items: [
                  "Large down payment needed (typically 10-20%)",
                  "Mortgage debt for 20-30 years",
                  "Maintenance and repair costs",
                  "Less flexibility to move",
                  "Risk if property value decreases",
                ],
              },
            ],
          },
        },
        {
          type: "importance",
          content: {
            title: "Why it matters",
            text: "This decision affects your finances for decades. Your earlier choices about budgeting, saving, and managing debt determine whether buying is even possible. Those who saved and built emergency funds have more options.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your Task",
            description:
              "Based on your financial history, what housing decision will you make?",
            choices: [
              {
                text: "A) Try to buy an apartment with a large loan.",
                cashChange: -5000,
                happinessChange: -20,
                stressChange: 50,
                safetyChange: -30,
                requiresFlag: "wentIntoDebt", // Only available if they have debt history
                result:
                  "You tried to buy, but because you've been in debt before and don't have savings, the bank rejected your loan application. You wasted €5000 on application fees, inspections, and legal consultations. This was a costly mistake that could have been avoided with better financial planning earlier.",
                tip: "Banks check your financial history. Past debt and lack of savings hurt your chances. Start building good credit and savings early.",
                flag: "loanRejected",
              },
              {
                text: "B) Buy a small apartment with a reasonable loan.",
                cashChange: -3000,
                happinessChange: 15,
                stressChange: 20,
                safetyChange: 40,
                requiresFlag: "hasBudget", // Need good financial history
                requiresFlag2: "increasedIncome", // AND increased income
                result:
                  "Because you budgeted well and increased your income earlier, you had a €10,000 down payment saved! The bank approved your loan. You bought a small 35m² apartment. Monthly mortgage payments are manageable. You're building equity while your friends are still renting. You feel proud and financially secure!",
                tip: "Your consistent good decisions from age 18 made this possible! Early planning pays off.",
                flag: "homeowner",
              },
              {
                text: "C) Continue renting but in a better location.",
                cashChange: -300,
                happinessChange: 10,
                stressChange: -5,
                safetyChange: 10,
                socialChange: 15,
                result:
                  "You decided renting gives you more flexibility right now. You moved to a nicer apartment closer to work and friends. You're saving the money you would have spent on a down payment and investing it instead. You're happy with your choice.",
                tip: "Renting isn't 'wasting money' if it fits your lifestyle and goals. Buying isn't always the right choice for everyone.",
                flag: "strategicRenter",
              },
              {
                text: "D) Stay in your current cheap apartment and save aggressively.",
                cashChange: 500,
                happinessChange: -10,
                stressChange: -15,
                safetyChange: 50,
                requiresFlag: "hasBudget",
                result:
                  "You kept your cheap student apartment and saved €500/month. In one year, you'll have €6000 saved. Your friends think you're crazy, but you're building serious financial security. You're playing the long game.",
                tip: "Delayed gratification is a powerful wealth-building tool. Future you will thank present you.",
                flag: "aggressiveSaver",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Housing is typically your biggest expense. Your ability to make good housing decisions depends on years of prior financial responsibility.",
    },
  ],

  bank: [
    // ACTIVE: Swipe, Save, or Spill? - Multi-page scenario
    {
      title: "💳 Swipe, Save, or Spill?",
      isMultiPage: true,
      pages: [
        {
          type: "intro",
          content: {
            title: "💳 Swipe, Save, or Spill?",
            storyIntro:
              "Your first credit card offer arrived, and an investment opportunity popped up online. How will you use these tools wisely?",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Credit Cards & Investments",
            description:
              "Credit cards let you borrow money to buy things now and pay later. Using them responsibly builds a good credit history, but unpaid balances charge interest. Investments let your money grow over time through stocks, funds, or savings accounts. Their value can go up or down, so there's a risk of losing money. Both tools can help you manage and grow your money if used wisely.",
          },
        },
        {
          type: "importance",
          content: {
            title: "Why it matters",
            text: "Overspending on credit cards or paying only the minimum can lead to high-interest debt and hurt your credit score. Investing without understanding the risks can make you lose money, especially if emergency savings are used.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your task",
            description:
              "Decide how much you'll spend with a credit card and how much to invest this month. Watch the long-term impact on your budget and goals.",
            choices: [
              {
                text: "A) I will use my credit card in everything! Who cares responsibility?",
                moneyChange: -200,
                happinessChange: 15,
                safetyChange: -35,
                stressChange: 25,
                result:
                  "You used your credit card for everything without tracking your spending! The interest piled up quickly, and you struggled to pay it off. You ended up with €200 in debt and a damaged credit score. The stress was overwhelming.",
                tip: "Use credit cards only for purchases you can repay on time. Track your spending. Start investing with small amounts, focus on long-term growth, and keep your emergency fund separate from investments.",
              },
              {
                text: "B) I will use credit card with great responsibility.",
                moneyChange: 100,
                happinessChange: -5,
                safetyChange: 30,
                stressChange: -15,
                result:
                  "You used your credit card responsibly, only for planned purchases you could pay back immediately. You also invested €100 in a long-term fund after keeping your emergency savings separate. You felt confident and in control of your financial future!",
                tip: "Use credit cards only for purchases you can repay on time. Track your spending. Start investing with small amounts, focus on long-term growth, and keep your emergency fund separate from investments.",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Credit cards and investments are powerful tools when used responsibly. Always pay your credit card balance on time and invest only money you can afford to lose.",
    },
  ],

  mall: [],

  hospital: [
    // ACTIVE: Save for Whoopsies & Wishlist - Multi-page scenario
    {
      title: "Save for Whoopsies & Wishlist",
      isMultiPage: true,
      pages: [
        {
          type: "intro",
          content: {
            title: "Save for Whoopsies & Wishlist",
            storyIntro:
              "Life is full of surprises and planned expenses. Will you have money ready when things happen?",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Emergency Fund vs Sinking Fund",
            description:
              "Understanding the difference between these two types of savings is essential for financial security.",
            microExamples: [
              "An emergency fund is money saved for unexpected events like illness, job loss, or urgent repairs.",
              "A sinking fund is money saved bit by bit for planned expenses, such as holidays, birthdays, or buying gadgets.",
              "Emergencies are surprises, while sinking funds are planned.",
            ],
            macroExamples: [
              "Keeping both separate ensures that money for planned things isn't used for emergencies.",
              "Emergency money isn't spent on planned goals.",
              "Over time, this helps you feel confident and secure with your finances.",
            ],
          },
        },
        {
          type: "importance",
          content: {
            title: "Why it matters",
            text: "Using your emergency fund for non-urgent or planned expenses can leave you unprepared for real emergencies. Borrowing from sinking funds for impulse purchases can derail savings and create last-minute stress.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your task",
            description:
              "Set up your emergency fund and one or two sinking funds. Decide how much to allocate to each and track your progress for the next in-game month.",
            choices: [
              {
                text: "I don't care about sinking funds. It's so unnecessary.",
                moneyChange: 0,
                happinessChange: 10,
                safetyChange: -30,
                stressChange: 20,
                result:
                  "You decided to skip setting up sinking funds. While you feel free now, unexpected planned expenses might catch you off guard later, forcing you to dip into emergency savings or go into debt.",
                tip: "Keep emergency and sinking funds in different places. Save a little each week and check your progress. This makes it easier to reach your goals without stress.",
              },
              {
                text: "Future is unpredictable. Better to be prepared than sorry.",
                moneyChange: 0,
                happinessChange: 5,
                safetyChange: 40,
                stressChange: -20,
                result:
                  "You set up both emergency and sinking funds wisely! You allocated money for unexpected events and planned expenses. This preparation gives you financial confidence and reduces stress about the future.",
                tip: "Keep emergency and sinking funds in different places. Save a little each week and check your progress. This makes it easier to reach your goals without stress.",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Separating emergency and sinking funds helps you stay prepared for both surprises and planned expenses.",
    },
  ],

  casino: [
    // ACTIVE: When Life Throws You Lemon - Multi-page scenario
    {
      title: "🍋 When life throws you lemon...",
      isMultiPage: true,
      pages: [
        {
          type: "intro",
          content: {
            title: "🍋 When life throws you lemon...",
            storyIntro:
              "Oh no! Life throws surprises at you. Your phone breaks, bills rise, and sometimes prices across the country suddenly increase. Can you stay on top of your budget?",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Lesson – Unexpected Costs",
            description:
              "Unexpected costs are expenses that come up suddenly and weren't planned. They can happen at:",
            microExamples: [
              "Your phone or laptop breaks and needs repair.",
              "A school trip or hobby activity costs more than expected.",
              "Unplanned medical bills or medications.",
              "Friends or family ask for help unexpectedly.",
            ],
            macroExamples: [
              "Prices of everyday goods rise (inflation).",
              "Taxes or fees increase.",
              "New laws or regulations add costs (e.g., environmental taxes).",
              "Economic events like recessions make goods more expensive.",
            ],
          },
        },
        {
          type: "importance",
          content: {
            title: "Why this matters",
            text: "Unexpected costs can make it hard to stick to your budget. If you're not prepared, you may have to borrow money, skip planned goals, or reduce spending on important things. Without savings or a plan, unexpected costs can force you to borrow money or skip important purchases. Rising prices at the macro level make everything more expensive, even things you buy every week.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your Task",
            description:
              'Adjust your monthly budget to include an "unexpected costs" buffer. Decide how much to save for micro surprises and macro-level changes.',
            choices: [
              {
                text: "A) Ignore the economics. Gambling will fix all my finance worries.",
                moneyChange: -1000,
                happinessChange: -15,
                safetyChange: -20,
                result:
                  "You decided to gamble instead of saving for unexpected costs. You lost €1000 at the casino. When your phone broke next month, you had no money left and had to borrow from friends. You felt stressed and regretful.",
                tip: "Keep a little extra money aside for surprises. Track your spending so you notice patterns. For bigger economy-wide changes, like rising prices, save a bit more each month to avoid being caught off guard.",
              },
              {
                text: "B) Take micro- and macro economics seriously. Gambling is short and risky choice.",
                moneyChange: 150,
                happinessChange: -5,
                safetyChange: 25,
                result:
                  "You avoided the casino and instead saved €150 for unexpected costs. When your laptop needed repairs, you were prepared! You felt less stressed knowing you had a buffer, even though it meant skipping some entertainment this month.",
                tip: "Keep a little extra money aside for surprises. Track your spending so you notice patterns. For bigger economy-wide changes, like rising prices, save a bit more each month to avoid being caught off guard.",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Building an emergency fund helps you handle unexpected costs without going into debt. Gambling is never a solution to financial problems.",
    },
  ],

  school: [
    // PLACEHOLDER: School scenario coming soon
    {
      title: "🎓 School: Financial Education",
      isMultiPage: true,
      pages: [
        {
          type: "intro",
          content: {
            title: "🎓 Welcome to Financial Education!",
            storyIntro:
              "School isn't just about textbooks and exams - it's also where you learn to manage money wisely. Let's explore how education can impact your financial future!",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Lesson – Education & Financial Success",
            description:
              "Education opens doors to better financial opportunities:",
            sections: [
              {
                title: "Skills Development",
                subtitle: "Building your knowledge:",
                items: [
                  "Financial literacy courses",
                  "Career-specific training",
                  "Entrepreneurship skills",
                  "Digital and technology skills",
                ],
              },
              {
                title: "Career Opportunities",
                subtitle: "Better education often leads to:",
                items: [
                  "Higher starting salaries",
                  "More job security",
                  "Career advancement options",
                  "Networking opportunities",
                ],
              },
              {
                title: "Investment in Yourself",
                subtitle: "Education is an investment:",
                items: [
                  "Higher lifetime earnings",
                  "Better financial decision-making",
                  "More career flexibility",
                  "Personal growth and confidence",
                ],
              },
            ],
          },
        },
        {
          type: "importance",
          content: {
            title: "Why this matters",
            text: "Investing in education is one of the best financial decisions you can make. In Finland, education is largely free or affordable, making it an excellent opportunity to build skills without massive debt. The knowledge and connections you gain can multiply your earning potential for decades.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your Task",
            description:
              "You have an opportunity to take a financial literacy course at school. It costs time and effort, but could improve your money management skills. What will you do?",
            choices: [
              {
                text: "A) Skip the course and focus on having fun with friends.",
                happinessChange: 10,
                funChange: 15,
                result:
                  "You had a great time hanging out with friends! But later in the year, you made some costly financial mistakes that could have been avoided with better knowledge.",
                tip: "Education doesn't stop in the classroom. Every skill you learn can pay dividends in the future.",
              },
              {
                text: "B) Take the financial literacy course seriously.",
                happinessChange: -5,
                safetyChange: 20,
                socialChange: -10,
                result:
                  "The course required effort and you missed some social events, but you learned valuable skills about budgeting, saving, and investing. You feel more confident about managing your money!",
                tip: "Knowledge is power, especially when it comes to money. The skills you learn now will serve you for a lifetime.",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Education is one of the best investments you can make in yourself. In Finland, take advantage of the accessible education system to build skills that will benefit your financial future.",
    },
  ],

  office: [
    // ACTIVE: Paycheck Puzzle - Multi-page scenario
    {
      title: "💼 Paycheck Puzzle: Taxes, Pension & More!",
      isMultiPage: true,
      pages: [
        {
          type: "intro",
          content: {
            title: "💼 Paycheck Puzzle: Taxes, Pension & More!",
            storyIntro:
              "Congrats! Your first paycheck just arrived. But wait… why is the amount less than you expected? Let's break it down and see where your money goes before it lands in your account.",
          },
        },
        {
          type: "lesson",
          content: {
            title: "Lesson – What Happens to Your Paycheck",
            description:
              "When you get paid in Finland, several deductions are automatically taken:",
            deductions: [
              {
                title: "💼 Taxes:",
                text: "Income tax goes to the government to pay for schools, healthcare, roads, and other services.",
              },
              {
                title: "💼 Pension Contribution:",
                text: "A portion of your salary goes into a pension fund for your future retirement.",
              },
              {
                title:
                  "💼 Unemployment Insurance (Työttömyysvakuutus):",
                text: "Helps provide support if you lose your job unexpectedly.",
              },
            ],
            conclusion:
              "After these deductions, the remaining money is your net salary, which you can spend, save, or invest.",
          },
        },
        {
          type: "importance",
          content: {
            title: "Why it matters",
            text: "Understanding your paycheck helps you: Know how much you really have to spend, plan your budget effectively, and avoid surprises when paying bills or saving. Ignoring deductions can lead to confusion and overspending. Misunderstanding your net salary may make it harder to budget for essentials, emergencies, and fun activities.",
            bulletPoints: [
              "Know how much you really have to spend.",
              "Plan your budget effectively.",
              "Avoid surprises when paying bills or saving.",
            ],
            warning:
              "Ignoring deductions can lead to confusion and overspending. Misunderstanding your net salary may make it harder to budget for essentials, emergencies, and fun activities.",
          },
        },
        {
          type: "task",
          content: {
            title: "Your Task",
            description:
              "Open your first virtual paycheck. Identify taxes, pension contributions, and unemployment deductions. Calculate your net income and assign it to Needs, Wants, and Future You in your budget. Watch how this affects your stress level and progress toward goals in the game.",
            choices: [
              {
                text: "A) Ignore this and live a life of ignorance.",
                happinessChange: 5,
                safetyChange: -20,
                result:
                  "You chose to ignore your paycheck details. A few months later, you were surprised when bills came due and you didn't have enough money. You overspent thinking you had more than you actually did, and now you're stressed about making ends meet.",
                tip: "Check your pay slip carefully each month. Keep track of deductions and calculate your net income. Use your net income to plan your budget using the 50–30–20 rule.",
              },
              {
                text: "B) Take responsibility about this.",
                happinessChange: -5,
                safetyChange: 25,
                result:
                  "You carefully reviewed your paycheck and understood where every euro went. You created a budget based on your net salary and felt more in control. Though it was a bit overwhelming at first, you now feel confident managing your money and planning for the future.",
                tip: "Check your pay slip carefully each month. Keep track of deductions and calculate your net income. Use your net income to plan your budget using the 50–30–20 rule.",
              },
            ],
          },
        },
      ],
      educationalNote:
        "Understanding your paycheck helps you budget better and plan for the future.",
    },
  ],

  store: [
    // ACTIVE: Shopping - Multi-page scenario
    {
      title: "🛒 Shopping",
      isMultiPage: true,
      pages: [
        {
          type: "intro",
          content: {
            title: "🛒 Shopping",
            storyIntro:
              "Now you have to buy all necessary things. Be careful to not overbudget it.",
          },
        },
        {
          type: "dragdrop",
          content: {
            title: "Shopping Time",
            items: [
              { id: "food", text: "Food", price: 20 },
              {
                id: "toilet",
                text: "Toilet supplies",
                price: 10,
              },
              { id: "clothes", text: "Clothes", price: 200 },
              { id: "games", text: "Video games", price: 150 },
            ],
          },
        },
        {
          type: "shoppingresult",
          content: {
            title: "Shopping Results",
          },
        },
      ],
      educationalNote:
        "Learning to budget for necessities helps you avoid overspending and stay financially stable.",
    },
  ],
};