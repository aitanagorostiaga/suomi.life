export interface LifeEvent {
  id: string;
  title: string;
  description: string;
  cashChange: number;
  happinessChange?: number;
  stressChange?: number;
  safetyChange?: number;
  funChange?: number;
  socialChange?: number;
  requiresFlag?: string; // Story-based events require specific flags
  isPositive: boolean;
}

export const lifeEvents: LifeEvent[] = [
  // ===== STORY-BASED EVENTS (5) =====
  {
    id: "investment-dividend",
    title: "💰 Investment Returns!",
    description: "Your smart investment decision is paying off! You received a quarterly dividend from your portfolio.",
    cashChange: 180,
    happinessChange: 15,
    stressChange: -10,
    safetyChange: 10,
    requiresFlag: "hasBudget",
    isPositive: true,
  },
  {
    id: "debt-collector-call",
    title: "📞 Debt Collector Warning",
    description: "A debt collector called about your unpaid bills. They added a late fee to your account. This is stressful and embarrassing.",
    cashChange: -150,
    happinessChange: -20,
    stressChange: 35,
    safetyChange: -25,
    socialChange: -10,
    requiresFlag: "wentIntoDebt",
    isPositive: false,
  },
  {
    id: "side-gig-bonus",
    title: "🎉 Side Gig Bonus!",
    description: "Your side gig client was so impressed with your work that they gave you a bonus and referred you to two more clients!",
    cashChange: 250,
    happinessChange: 20,
    stressChange: -15,
    safetyChange: 15,
    socialChange: 10,
    requiresFlag: "increasedIncome",
    isPositive: true,
  },
  {
    id: "rent-increase-prepared",
    title: "🏠 Rent Increase (But You're Ready!)",
    description: "Your landlord increased rent by €100/month, but because you've been budgeting well, you already have a cushion saved. You adjust your budget and move on confidently.",
    cashChange: -100,
    happinessChange: 5,
    stressChange: 5,
    safetyChange: 10,
    requiresFlag: "hasBudget",
    isPositive: false,
  },
  {
    id: "credit-score-reward",
    title: "✨ Good Credit Score Benefits",
    description: "Your bank noticed your excellent financial behavior and offered you a lower interest rate on future loans, plus a small loyalty bonus!",
    cashChange: 120,
    happinessChange: 15,
    stressChange: -10,
    safetyChange: 20,
    requiresFlag: "hasBudget",
    isPositive: true,
  },

  // ===== GENERIC EVENTS (15) =====
  {
    id: "birthday-money",
    title: "🎂 Birthday Money!",
    description: "It's your birthday! Your family sent you some birthday money. Time to treat yourself... or save it?",
    cashChange: 150,
    happinessChange: 15,
    funChange: 10,
    socialChange: 10,
    isPositive: true,
  },
  {
    id: "phone-broke",
    title: "📱 Phone Screen Cracked",
    description: "Oh no! You dropped your phone and the screen completely shattered. You need to get it repaired or you can't work properly.",
    cashChange: -280,
    happinessChange: -15,
    stressChange: 25,
    isPositive: false,
  },
  {
    id: "found-money",
    title: "💵 Found Money!",
    description: "You found €50 in your old jacket pocket! What a nice surprise!",
    cashChange: 50,
    happinessChange: 10,
    funChange: 5,
    isPositive: true,
  },
  {
    id: "medical-emergency",
    title: "🏥 Unexpected Medical Bill",
    description: "You had to visit the doctor for a sudden illness. Even with insurance, you have to pay for medication and the co-pay.",
    cashChange: -180,
    happinessChange: -10,
    stressChange: 20,
    safetyChange: -15,
    isPositive: false,
  },
  {
    id: "tax-refund",
    title: "💸 Tax Refund!",
    description: "You received a tax refund from last year! You forgot you overpaid your taxes. Nice surprise!",
    cashChange: 320,
    happinessChange: 20,
    stressChange: -15,
    safetyChange: 10,
    isPositive: true,
  },
  {
    id: "laptop-repair",
    title: "💻 Laptop Broke Down",
    description: "Your laptop started making weird noises and won't turn on anymore. You need it for work and school, so you have to get it repaired urgently.",
    cashChange: -350,
    happinessChange: -20,
    stressChange: 35,
    safetyChange: -10,
    isPositive: false,
  },
  {
    id: "friend-repaid-loan",
    title: "🤝 Friend Paid You Back!",
    description: "Remember that money you lent to your friend months ago? They finally paid you back with interest as a thank you!",
    cashChange: 110,
    happinessChange: 10,
    socialChange: 15,
    isPositive: true,
  },
  {
    id: "parking-ticket",
    title: "🚗 Parking Ticket",
    description: "You parked in the wrong spot for just 10 minutes and got a parking ticket. The fine is expensive and frustrating.",
    cashChange: -80,
    happinessChange: -10,
    stressChange: 15,
    isPositive: false,
  },
  {
    id: "freelance-gig",
    title: "💼 One-Time Freelance Gig",
    description: "A friend referred you for a one-time freelance project. You completed it over the weekend and got paid! Easy money!",
    cashChange: 200,
    happinessChange: 15,
    funChange: -10,
    stressChange: 10,
    safetyChange: 10,
    isPositive: true,
  },
  {
    id: "utility-spike",
    title: "⚡ Electricity Bill Spike",
    description: "This month's electricity bill is unusually high due to the cold weather. You had to use more heating than expected.",
    cashChange: -95,
    happinessChange: -5,
    stressChange: 15,
    isPositive: false,
  },
  {
    id: "won-raffle",
    title: "🎰 Won a Small Raffle!",
    description: "You entered a raffle at a local store and actually won! You received a gift card that you can use for groceries or sell for cash.",
    cashChange: 75,
    happinessChange: 15,
    funChange: 10,
    isPositive: true,
  },
  {
    id: "bike-stolen",
    title: "🚲 Bike Stolen",
    description: "Your bike was stolen from outside your apartment. Now you need to buy a new one or pay more for public transport.",
    cashChange: -220,
    happinessChange: -20,
    stressChange: 25,
    safetyChange: -15,
    socialChange: -5,
    isPositive: false,
  },
  {
    id: "scholarship-bonus",
    title: "📚 Scholarship Grant",
    description: "Your university approved a small scholarship grant for your good grades! This will help with books and supplies.",
    cashChange: 400,
    happinessChange: 25,
    stressChange: -20,
    safetyChange: 20,
    isPositive: true,
  },
  {
    id: "gym-annual-fee",
    title: "🏋️ Unexpected Annual Fee",
    description: "You forgot that your gym membership has an annual maintenance fee. It just got charged to your account automatically.",
    cashChange: -120,
    happinessChange: -10,
    stressChange: 15,
    isPositive: false,
  },
  {
    id: "sold-old-stuff",
    title: "🛍️ Sold Old Items Online",
    description: "You cleaned your room and sold some old electronics, clothes, and books online. Decluttering and earning money feels great!",
    cashChange: 140,
    happinessChange: 15,
    funChange: 5,
    stressChange: -10,
    isPositive: true,
  },
];

/**
 * Get a random life event based on player's game history
 * Returns null if no suitable event found
 */
export function getRandomLifeEvent(playerHistory: string[]): LifeEvent | null {
  // Filter events based on flags
  const availableEvents = lifeEvents.filter(event => {
    // If event requires a flag, check if player has it
    if (event.requiresFlag) {
      return playerHistory.includes(event.requiresFlag);
    }
    // Generic events are always available
    return true;
  });

  if (availableEvents.length === 0) {
    return null;
  }

  // Return random event from available ones
  const randomIndex = Math.floor(Math.random() * availableEvents.length);
  return availableEvents[randomIndex];
}
