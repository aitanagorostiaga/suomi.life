Este archivo de Figma Make incluye componentes de [shadcn/ui](https://ui.shadcn.com/) que se utilizan con [licencia de MIT](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Este archivo de Figma Make incluye fotos de [Unsplash](https://unsplash.com) utilizadas con licencia de [licencia](https://unsplash.com/license).