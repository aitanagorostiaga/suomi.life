
  # COPY Suomi Life version Budget - Junction 2025 (copia)

  This is a code bundle for COPY Suomi Life version Budget - Junction 2025 (copia). The original project is available at https://www.figma.com/design/poMr88JR5fs7FM977ziNjX/COPY-Suomi-Life-version-Budget---Junction-2025--copia-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  